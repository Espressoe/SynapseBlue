﻿using Guna.UI2.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SynapseBlue
{
    public partial class Loader : Form
    {
        Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
        public Loader()
        {
            InitializeComponent();
        }

        private async void guna2Button1_Click(object sender, EventArgs e)
        {

            if (guna2TextBox2.Text == "")
            {
                MessageBox.Show("You Have To Insert Your Krampus Key To Continue!", "Synapse Login Error");
            }
            else
            {
                config.AppSettings.Settings["key"].Value = guna2TextBox2.Text;
                config.Save(ConfigurationSaveMode.Modified);
                panel1.Visible = false;
                guna2GradientPanel1.Visible = true;
                label2.Text = "Initializing...";
                await Task.Delay(1000);
                guna2GradientPanel1.Location = new Point(36, 221);
                guna2CircleButton2.Checked = true;
                await Task.Delay(1999);
                label3.Text = "Checking For Updates";
                label4.Text = "We Are Validating Your Synapse Version \r\nWith The Synapse Servers";
                guna2GradientPanel1.Location = new Point(36, 259);
                guna2CircleButton4.Checked = true;
                await Task.Delay(1999);
                label3.Text = "Checking Your Synapse Key";
                label4.Text = "We Are Validating Your Synapse Key \r\nWith The Synapse Servers";
                guna2GradientPanel1.Location = new Point(36, 301);
                guna2CircleButton5.Checked = true;
                await Task.Delay(1999);
                label3.Text = "Checking Your ROBLOX Version";
                label4.Text = "We Are Validating Your ROBLOX Version \r\nWith The Synapse Servers";
                guna2GradientPanel1.Location = new Point(35, 363);
                guna2CircleButton3.Checked = true;
                MainWindow mw = new MainWindow();
                mw.Show();
                this.Hide();
            }
        }

        private void guna2CircleButton3_Click(object sender, EventArgs e)
        {

        }

        private void Loader_Load(object sender, EventArgs e)
        {
            guna2TextBox2.Text = config.AppSettings.Settings["key"].Value.ToString();
        }
    }
}
