﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.WebSockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;

namespace SynapseBlue
{
    public partial class MainWindow : Form
    {
        private static ClientWebSocket websocket;
        UserControl1 tabs = new UserControl1();
        private const int cGripSize = 16; // Grip size for resizing
        private string folderPath = Directory.GetCurrentDirectory() + "//Scripts";

        private bool resizing = false;
        private int resizeStartX, resizeStartY;
        public MainWindow()
        {
            InitializeComponent();
            LoadFiles();
            this.Text = "https://discord.gg/9VDxa7fqq5";
        }

        private void guna2Button4_Click(object sender, EventArgs e)
        {

        }
        private void FileUserControl_FileClicked(object sender, EventArgs e)
        {
            script clickedControl = (script)sender;
            string fileName = clickedControl.FileName;
            string fileData = File.ReadAllText(Path.Combine(folderPath, fileName));
            tabs.current_monaco().SetText(fileData);
        }
        private void LoadFiles()
        {
            flowLayoutPanel1.Controls.Clear();
            string[] files = Directory.GetFiles(folderPath);

            foreach (string file in files)
            {
                string fileName = Path.GetFileName(file);

                script fileUserControl = new script();
                fileUserControl.FileName = fileName;
                fileUserControl.FileClicked += FileUserControl_FileClicked;

                flowLayoutPanel1.Controls.Add(fileUserControl);
            }
        }
        private void MainWindow_MouseDown(object sender, MouseEventArgs e)
        {
            // Check if the user is clicking on the resize grip
            if (e.Button == MouseButtons.Left && ClientRectangle.Contains(e.Location))
            {
                resizing = true;
                resizeStartX = e.X;
                resizeStartY = e.Y;
            }
        }

        private void MainWindow_MouseMove(object sender, MouseEventArgs e)
        {
            // If resizing, change the form size based on the mouse movement
            if (resizing)
            {
                int deltaX = e.X - resizeStartX;
                int deltaY = e.Y - resizeStartY;
                Size = new System.Drawing.Size(Size.Width + deltaX, Size.Height + deltaY);
            }
        }

        private void MainWindow_MouseLeave(object sender, EventArgs e)
        {

        }

        private void MainWindow_MouseUp(object sender, MouseEventArgs e)
        {
            // Stop resizing when the mouse button is released
            resizing = false;
        }

        private void MainWindow_ParentChanged(object sender, EventArgs e)
        {

        }
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            // Draw a resize grip at the bottom right corner
            var rect = new System.Drawing.Rectangle(ClientSize.Width - cGripSize, ClientSize.Height - cGripSize, cGripSize, cGripSize);
            ControlPaint.DrawSizeGrip(e.Graphics, BackColor, rect);
        }
        private void MainWindow_Paint(object sender, PaintEventArgs e)
        {
            
        }

        private void guna2CircleButton1_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void guna2CircleButton2_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void fileSystemWatcher1_Changed(object sender, FileSystemEventArgs e)
        {
            LoadFiles();
        }

        private void fileSystemWatcher1_Created(object sender, FileSystemEventArgs e)
        {
            LoadFiles();

        }

        private void fileSystemWatcher1_Deleted(object sender, FileSystemEventArgs e)
        {
            LoadFiles();

        }

        private void fileSystemWatcher1_Renamed(object sender, RenamedEventArgs e)
        {
            LoadFiles();

        }

        private void guna2Button6_Click(object sender, EventArgs e)
        {
            tabs.current_monaco().SetText("");
        }

        private void guna2Button7_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.DefaultExt = "lua";
            bool? nullable = openFileDialog.ShowDialog() == DialogResult.OK;
            bool flag = true;
            if (!(nullable.GetValueOrDefault() == flag & nullable.HasValue))
                return;
            string str = File.ReadAllText(openFileDialog.FileName);
            tabs.current_monaco().SetText(str);
        }
        static async Task Connect()
        {
            string loginToken = $"{ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None).AppSettings.Settings["key"].Value}";

            Uri uri = new Uri($"wss://loader.live/?login_token=\"{loginToken}\"");

            websocket = new ClientWebSocket();
            await websocket.ConnectAsync(uri, CancellationToken.None);
        }

        public static async Task Execute(string code)
        {
            await Connect();
            byte[] buffer = Encoding.UTF8.GetBytes("<SCRIPT>" + code);
            await websocket.SendAsync(new ArraySegment<byte>(buffer), WebSocketMessageType.Text, true, CancellationToken.None);
        }
        private void guna2Button10_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.InitialDirectory = Directory.GetCurrentDirectory() + "\\Scripts";
            saveFileDialog.DefaultExt = "lua";
            saveFileDialog.Filter = "Lua files (*.lua)|*.lua";
            bool? nullable = saveFileDialog.ShowDialog() == DialogResult.OK;
            bool flag = true;
            if (!(nullable.GetValueOrDefault() == flag & nullable.HasValue))
                return;
            File.WriteAllText(saveFileDialog.FileName, tabs.current_monaco().GetText().ToString());
        }

        private void guna2Button8_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.DefaultExt = "lua";
            bool? nullable = openFileDialog.ShowDialog() == DialogResult.OK;
            bool flag = true;
            if (!(nullable.GetValueOrDefault() == flag & nullable.HasValue))
                return;
            string str = File.ReadAllText(openFileDialog.FileName);
            _ = Execute(str);
        }

        private void guna2Button5_Click(object sender, EventArgs e)
        {
            _ = Execute(tabs.current_monaco().GetText().ToString());
        }

        private void guna2Button9_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void guna2Button11_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;

        }

        private void MainWindow_Load(object sender, EventArgs e)
        {
           elementHost1.Child = tabs;
        }
    }
}
